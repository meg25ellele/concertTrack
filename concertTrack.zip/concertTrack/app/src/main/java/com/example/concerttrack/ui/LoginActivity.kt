package com.example.concerttrack.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.concerttrack.R
import com.example.concerttrack.util.Constants
import com.example.concerttrack.util.content

import com.example.concerttrack.viewmodel.FanRegisterViewModel
import com.example.concerttrack.viewmodel.LoginViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_login.registerBtn

class LoginActivity : AppCompatActivity() {


    private val loginViewModel: LoginViewModel by lazy {
        ViewModelProvider(this).get(LoginViewModel::class.java) }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        loginViewModel.userLiveData?.observe(this, Observer<FirebaseUser>{ firebaseUser ->
            if(firebaseUser != null) {
                startActivity(Intent(this,FanMainPageActivity::class.java))
            }
        })

        val userTypeName = intent.getStringExtra(Constants.USER_TYPE)

        when(userTypeName) {
            Constants.ARTIST_TYPE_STR -> {
                loginInfo.text = getText(R.string.loginArtistInfo)
                userTypeIcon.setImageResource(R.drawable.star)
                registerBtn.setOnClickListener {
                    startActivity(Intent(this,ArtistRegisterActivity::class.java))
                }
            }
            Constants.FAN_TYPE_STR -> {
                loginInfo.text = getText(R.string.loginFanInfo)
                userTypeIcon.setImageResource(R.drawable.user)
                registerBtn.setOnClickListener {
                    startActivity(Intent(this,FanRegisterActivity::class.java))
                }

            }
        }

        logInBtn.setOnClickListener {
            if( areInputValid()) {
                loginViewModel.login(mailLoginET.text.toString(),passwordLoginET.text.toString())
            }
        }
    }

    private fun areInputValid(): Boolean {
        isNotPasswordEmpty()
        isNotEmailEmpty()

        return isNotPasswordEmpty() && isNotEmailEmpty()
    }

    private fun isNotEmailEmpty(): Boolean {
        val isNotEmailEmpty = mailLoginET.content().isNotEmpty()
        if (!isNotEmailEmpty) {
            mailLoginET.error = "Wpisz swój adres email."

        }

        return isNotEmailEmpty
    }

    private fun isNotPasswordEmpty(): Boolean {
        val isNotPasswordEmpty = passwordLoginET.content().isNotEmpty()
        if (!isNotPasswordEmpty) {
            passwordLoginET.error = "Wpisz poprawne hasło."
        }

        return isNotPasswordEmpty
    }

}