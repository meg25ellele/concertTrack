package com.example.concerttrack.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.concerttrack.R
import com.example.concerttrack.util.Constants
import com.example.concerttrack.viewmodel.FanRegisterViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.android.synthetic.main.activity_fan_register.*
import kotlinx.android.synthetic.main.activity_login.registerBtn


class FanRegisterActivity : AppCompatActivity() {

    private val fanRegisterViewModel: FanRegisterViewModel by lazy { ViewModelProvider(this).get(FanRegisterViewModel::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fan_register)

        registerBtn.setOnClickListener {
            fanRegisterViewModel.register(userEmail.text.toString(),userPassword.text.toString())
        }

        fanRegisterViewModel.userLiveData?.observe(this,Observer<FirebaseUser>{ firebaseUser ->
            if(firebaseUser != null) {
                Toast.makeText(this,"User created",Toast.LENGTH_SHORT).show()
                finish()
            }
        })
    }

}