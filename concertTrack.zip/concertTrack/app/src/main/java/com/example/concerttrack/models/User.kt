package com.example.concerttrack.models

import java.io.Serializable


class User(
    val id: String,
    val name: String,
    val email: String) : java.io.Serializable