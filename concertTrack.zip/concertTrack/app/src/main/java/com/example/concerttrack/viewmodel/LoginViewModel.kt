package com.example.concerttrack.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.concerttrack.repository.AuthAppRepository
import com.google.firebase.auth.FirebaseUser

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    val authAppRepository: AuthAppRepository by lazy { AuthAppRepository(application) }
    var userLiveData: MutableLiveData<FirebaseUser>? = null

    init {
        userLiveData = authAppRepository.userLiveData
    }

    fun login(email: String, password: String) {
        authAppRepository.loginUser(email,password)
    }
}